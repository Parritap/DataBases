create view DEPARTAMENTO_CURSO_CANTESTUDIANTES as
select
    d.nombre_departamento departamento,
    c.nombre_curso curso,
    count(i.ESTUDIANTE_ID) cantidad_estudiantes
from
    DEPARTAMENTO d
        INNER JOIN CURSO c ON c.DEPARTAMENTO_ID = d.ID_DEPARTAMENTO
        INNER JOIN INSCRIPCION i ON i.CURSO_ID = c.ID_CURSO
group by cube (d.nombre_departamento, c.nombre_curso)
order by departamento nulls last, curso nulls last
/

