create view CANTIDAD_INSCRIPCIONES as
(select c.ID_CURSO, c.NOMBRE_CURSO,
        subquery.totalInscritos
FROM
    CURSO c JOIN (select COUNT(*) as totalInscritos, CURSO_ID from INSCRIPCION group by CURSO_ID) subquery
    ON c.ID_CURSO = subquery.CURSO_ID)
/

