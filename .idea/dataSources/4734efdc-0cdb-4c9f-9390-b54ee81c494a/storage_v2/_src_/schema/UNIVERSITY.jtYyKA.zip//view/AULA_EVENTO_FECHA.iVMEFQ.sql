create view AULA_EVENTO_FECHA as
select a.ID_AULA,
       a.NOMBRE_AULA,
       e.NOMBRE_EVENTO,
       e.FECHA_EVENTO,
       extract(year from e.FECHA_EVENTO) as anio_evento,
       extract(month from e.FECHA_EVENTO) as mes_evento
from EVENTO e
         JOIN AULA a ON e.AULA_ID = a.ID_AULA
/

