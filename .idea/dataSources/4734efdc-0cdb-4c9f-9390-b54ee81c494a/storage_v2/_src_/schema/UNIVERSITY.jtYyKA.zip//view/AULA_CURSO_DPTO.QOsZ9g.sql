create view AULA_CURSO_DPTO as
select d.NOMBRE_DEPARTAMENTO as departamento,
       c.NOMBRE_CURSO,
       a.ID_AULA
from AULA a
         join CURSO c on a.ID_AULA = c.AULA_ID
         JOIN DEPARTAMENTO d on c.DEPARTAMENTO_ID = d.ID_DEPARTAMENTO
/

