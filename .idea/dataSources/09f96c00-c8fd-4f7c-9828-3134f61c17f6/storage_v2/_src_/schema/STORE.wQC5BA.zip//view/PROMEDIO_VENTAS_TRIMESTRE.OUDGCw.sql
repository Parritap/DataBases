create view PROMEDIO_VENTAS_TRIMESTRE as
select p.IDPRODUCTO,
       p.NOMBREPRODUCTO,
       to_char(f.FECHA, 'YYYY') anio,
       to_char(f.FECHA, 'Q') trimestre,
       AVG(d.CANTIDAD * (p.PRECIOVENTA - p.PRECIOCOMPRA)) avg
from FACTURAVENTA f
         join DETALLEVENTA d ON f.NUMEROORDEN = d.NUMEROORDEN
         right join PRODUCTO p ON d.IDPRODUCTO = p.IDPRODUCTO
group by p.IDPRODUCTO,
         p.NOMBREPRODUCTO,
         to_char(f.FECHA, 'YYYY'),
         to_char(f.FECHA, 'Q')
order by anio, trimestre ASC
/

