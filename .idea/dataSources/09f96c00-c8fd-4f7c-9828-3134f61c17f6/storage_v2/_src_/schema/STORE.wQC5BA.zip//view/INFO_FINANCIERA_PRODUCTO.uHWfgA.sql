create view INFO_FINANCIERA_PRODUCTO as
select subquery.IDPRODUCTO,
       p.NOMBREPRODUCTO,
       subquery.unidades_vendidas,
       (subquery.unidades_vendidas * (p.PRECIOVENTA - p.PRECIOCOMPRA)) ganancia_total
from (
    (select IDPRODUCTO, SUM(CANTIDAD) unidades_vendidas from
    producto_detalles group by IDPRODUCTO) subquery
    join PRODUCTO p on (subquery.IDPRODUCTO = p.IDPRODUCTO))
/

