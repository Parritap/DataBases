create view REPORTE_PRODUCTO as
select p.IDPRODUCTO producto,
       sub_cat.IDCATEGORIA subcategoria,
       cat.IDCATEGORIA categoria,
       SUM(d.CANTIDAD) as cantidad_vendida,
       SUM(d.CANTIDAD * (p.PRECIOVENTA - p.PRECIOCOMPRA)) as ganancia,
       grouping (sub_cat.IDCATEGORIA) bool_subcategoria,
       grouping (cat.IDCATEGORIA) bool_categoria
from
PRODUCTO p
left join CATEGORIA sub_cat on (p.CATEGORIA_IDCATEGORIA = sub_cat.IDCATEGORIA)
left join CATEGORIA cat on (sub_cat.IDCATEGORIAPADRE = cat.IDCATEGORIA)
left join DETALLEVENTA d on (d.IDPRODUCTO = p.IDPRODUCTO)
group by rollup  (p.IDPRODUCTO,cat.IDCATEGORIA,sub_cat.IDCATEGORIA)
/

