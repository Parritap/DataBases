create view CANTIDAD_TRIMESTRES (N) as
select count(*)
from (select to_char(f.FECHA, 'YYYY'),
             to_char(f.FECHA, 'Q')
      from FACTURAVENTA f
      group by to_char(f.FECHA, 'YYYY'),
               to_char(f.FECHA, 'Q'))
/

