create trigger CORREGIR_FACTURA
    before insert
    on ITEMVENTA
    for each row
DECLARE
    v_inventario number;
    v_num_venta  NUMBER;
    v_producto   NUMBER;
    aux_cursor   SYS_REFCURSOR;
BEGIN
    --Abrimos el cursor y le ingresamos los datos de la consulta. En este caso solo debería ser una fila.
    OPEN aux_cursor FOR
        SELECT inv.CANTIDAD as cant_inv,
               v.NUMERO     as venta
        FROM ALMACEN A
                 JOIN EMPLEADO E ON (A.IDALMACEN = E.ALMACEN_IDALMACEN)
                 JOIN VENTA V ON (V.NUMERO = :NEW.VENTA_NUMERO)
                 JOIN INVENTARIOALMACEN inv
                      ON (inv.ALMACEN_IDALMACEN = A.IDALMACEN
                          AND inv.PRODUCTO_IDPRODUCTO = :NEW.PRODUCTO_IDPRODUCTO);

    FETCH aux_cursor INTO v_inventario, v_num_venta;

    CLOSE aux_cursor;

    if (v_inventario < :NEW.cantidad) THEN
        UPDATE VENTA SET ESTADO = '0' WHERE NUMERO = :NEW.VENTA_NUMERO;
        DBMS_OUTPUT.PUT_LINE('La cantidad ingresada del producto es mayor que la cantidad en inventario, estado de la VENTA actualizado al valor "0" ');
    end if;
END;
/

