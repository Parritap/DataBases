create trigger MAX_4_SUBORDINATES
    instead of update of MANAGER_ID
    on EMPLOYEES
    for each row
    COMPOUND TRIGGER
    -- VARIABLES

    c_man_employees SYS_REFCURSOR;
    aux_record MANAGER_NUM_EMPLOYEES%ROWTYPE;


BEFORE STATEMENT IS
BEGIN
    open c_man_employees FOR SELECT * FROM MANAGER_NUM_EMPLOYEES;
END BEFORE STATEMENT;


BEFORE EACH ROW IS
BEGIN

    LOOP
        FETCH c_man_employees INTO aux_record;
        EXIT WHEN c_man_employees%NOTFOUND;

        IF aux_record.ID = :NEW.MANAGER_ID THEN
           EXIT;
        END IF;
    END LOOP;


   IF aux_record.NUM_SUBORDINATES >= 4 THEN
       RAISE_APPLICATION_ERROR(-20000, 'Es posible otorgar más de 4 subordinados al empleado' || :NEW.MANAGER_ID);
   end if;


   IF  aux_record.DEPARTMENT_ID != :OLD.DEPARTMENT_ID THEN
       RAISE_APPLICATION_ERROR(-20000, 'No es posible tener un jefe de distinto departamento');
   end if;




END BEFORE EACH ROW;
END;
/

