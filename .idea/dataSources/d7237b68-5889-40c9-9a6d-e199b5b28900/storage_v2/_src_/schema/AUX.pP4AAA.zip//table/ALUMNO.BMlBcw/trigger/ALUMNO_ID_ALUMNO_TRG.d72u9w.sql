create trigger ALUMNO_ID_ALUMNO_TRG
    before insert
    on ALUMNO
    for each row
    when (new.id_alumno IS NULL)
BEGIN
    :new.id_alumno := alumno_id_alumno_seq.nextval;
END;
/

