create trigger PRESENTACION_PREGUNTA_ID_PRESE
    before insert
    on PRESENTACION_PREGUNTA
    for each row
    when (new.id_presentacion_pregunta IS NULL)
BEGIN
    :new.id_presentacion_pregunta := presentacion_pregunta_id_prese.nextval;
END;
/

