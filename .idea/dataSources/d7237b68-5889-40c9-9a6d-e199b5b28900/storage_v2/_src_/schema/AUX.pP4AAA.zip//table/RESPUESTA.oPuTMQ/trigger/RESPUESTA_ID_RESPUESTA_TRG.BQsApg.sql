create trigger RESPUESTA_ID_RESPUESTA_TRG
    before insert
    on RESPUESTA
    for each row
    when (new.id_respuesta IS NULL)
BEGIN
    :new.id_respuesta := respuesta_id_respuesta_seq.nextval;
END;
/

