create trigger GRUPO_ID_GRUPO_TRG
    before insert
    on GRUPO
    for each row
    when (new.id_grupo IS NULL)
BEGIN
    :new.id_grupo := grupo_id_grupo_seq.nextval;
END;
/

