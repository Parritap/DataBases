create trigger TEMA_ID_TEMA_TRG
    before insert
    on TEMA
    for each row
    when (new.id_tema IS NULL)
BEGIN
    :new.id_tema := tema_id_tema_seq.nextval;
END;
/

