create trigger DOCENTE_ID_DOCENTE_TRG
    before insert
    on DOCENTE
    for each row
    when (new.id_docente IS NULL)
BEGIN
    :new.id_docente := docente_id_docente_seq.nextval;
END;
/

