create trigger CURSO_ID_CURSO_TRG
    before insert
    on CURSO
    for each row
    when (new.id_curso IS NULL)
BEGIN
    :new.id_curso := curso_id_curso_seq.nextval;
END;
/

