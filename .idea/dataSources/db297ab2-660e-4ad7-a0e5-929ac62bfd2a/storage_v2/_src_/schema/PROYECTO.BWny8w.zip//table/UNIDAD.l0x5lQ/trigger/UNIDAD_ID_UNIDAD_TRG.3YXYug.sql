create trigger UNIDAD_ID_UNIDAD_TRG
    before insert
    on UNIDAD
    for each row
    when (new.id_unidad IS NULL)
BEGIN
    :new.id_unidad := unidad_id_unidad_seq.nextval;
END;
/

