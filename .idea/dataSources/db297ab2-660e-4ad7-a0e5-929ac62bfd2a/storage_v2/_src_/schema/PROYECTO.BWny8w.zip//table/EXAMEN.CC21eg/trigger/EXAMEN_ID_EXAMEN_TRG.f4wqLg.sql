create trigger EXAMEN_ID_EXAMEN_TRG
    before insert
    on EXAMEN
    for each row
    when (new.id_examen IS NULL)
BEGIN
    :new.id_examen := examen_id_examen_seq.nextval;
END;
/

