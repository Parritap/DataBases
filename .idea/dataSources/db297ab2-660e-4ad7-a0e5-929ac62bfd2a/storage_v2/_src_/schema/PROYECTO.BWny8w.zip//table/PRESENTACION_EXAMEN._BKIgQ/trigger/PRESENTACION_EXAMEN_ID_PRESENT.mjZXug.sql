create trigger PRESENTACION_EXAMEN_ID_PRESENT
    before insert
    on PRESENTACION_EXAMEN
    for each row
    when (new.id_presentacion_examen IS NULL)
BEGIN
    :new.id_presentacion_examen := presentacion_examen_id_present.nextval;
END;
/

