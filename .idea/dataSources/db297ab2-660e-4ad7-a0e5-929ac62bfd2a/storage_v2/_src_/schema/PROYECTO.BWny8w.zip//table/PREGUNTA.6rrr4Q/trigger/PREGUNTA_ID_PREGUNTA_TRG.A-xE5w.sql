create trigger PREGUNTA_ID_PREGUNTA_TRG
    before insert
    on PREGUNTA
    for each row
    when (new.id_pregunta IS NULL)
BEGIN
    :new.id_pregunta := pregunta_id_pregunta_seq.nextval;
END;
/

