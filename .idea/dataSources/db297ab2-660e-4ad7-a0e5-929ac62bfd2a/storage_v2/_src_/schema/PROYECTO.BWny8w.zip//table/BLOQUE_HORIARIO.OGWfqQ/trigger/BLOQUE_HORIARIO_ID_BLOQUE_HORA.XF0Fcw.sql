create trigger BLOQUE_HORIARIO_ID_BLOQUE_HORA
    before insert
    on BLOQUE_HORIARIO
    for each row
    when (new.id_bloque_horario IS NULL)
BEGIN
    :new.id_bloque_horario := bloque_horiario_id_bloque_hora.nextval;
END;
/

