create trigger UPDATE_JOB_HISTORY
    ???
    on EMPLOYEES
BEGIN
  add_job_history(:old.employee_id, :old.hire_date, sysdate,
                  :old.job_id, :old.department_id);
END;
/

