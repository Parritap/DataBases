create trigger SECURE_EMPLOYEES
    ???
    on EMPLOYEES
BEGIN
  secure_dml;
END secure_employees;
/

